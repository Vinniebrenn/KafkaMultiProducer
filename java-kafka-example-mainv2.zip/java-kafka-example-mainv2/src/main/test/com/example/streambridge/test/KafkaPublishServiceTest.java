/*
 * package com.example.streambridge.test;
 * 
 * 
 * import static org.assertj.core.api.Assertions.assertThat; import static
 * org.junit.jupiter.api.Assertions.assertThrows; import static
 * org.mockito.ArgumentMatchers.*; import static org.mockito.Mockito.*;
 * 
 * import java.util.concurrent.CompletableFuture; import
 * java.util.concurrent.ExecutionException;
 * 
 * import org.apache.kafka.clients.producer.RecordMetadata; import
 * org.junit.jupiter.api.Test; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.test.context.SpringBootTest; import
 * org.springframework.boot.test.mock.mockito.MockBean; import
 * org.springframework.http.ResponseEntity;
 * 
 * import com.example.streambridge.config.KafkaProperties; import
 * com.example.streambridge.service.impl.KafkaPublishService; import
 * com.example.streambridge.util.KafkaProducerManager;
 * 
 * @SpringBootTest class KafkaPublishServiceTest {
 * 
 * @Autowired private KafkaPublishService kafkaPublishService;
 * 
 * @Autowired private KafkaProperties kafkaProperties;
 * 
 * @MockBean private KafkaProducerManager producerManager;
 * 
 * @Test void testPublish_Success() throws Exception { // Arrange
 * CompletableFuture<RecordMetadata> successfulFuture =
 * CompletableFuture.completedFuture(null);
 * when(producerManager.sendMessage(anyString(), anyString(), anyString(),
 * anyString(), anyString(), anyString(), anyString()))
 * .thenReturn(successfulFuture);
 * 
 * // Get a configured topic from kafkaProperties to avoid hardcoding String
 * topic = kafkaProperties.getTopics().get(0).getName(); String key =
 * "test-key"; String message = "test-message";
 * 
 * // Act ResponseEntity<String> response = kafkaPublishService.publish(topic,
 * key, message);
 * 
 * // Assert assertThat(response.getStatusCodeValue()).isEqualTo(200);
 * assertThat(response.getBody()).contains("Message published");
 * 
 * verify(producerManager, times(1)).sendMessage( eq(topic), eq(key),
 * eq(message), anyString(), eq(kafkaProperties.getBootstrapServers()),
 * anyString(), anyString()); }
 * 
 * @Test void testPublish_RetryOnFailure_ThenSuccess() throws Exception { //
 * Arrange: fail first 2 times, succeed on 3rd CompletableFuture<RecordMetadata>
 * failedFuture = new CompletableFuture<>();
 * failedFuture.completeExceptionally(new ExecutionException(new
 * RuntimeException("Simulated failure")));
 * 
 * CompletableFuture<RecordMetadata> successfulFuture =
 * CompletableFuture.completedFuture(null);
 * 
 * when(producerManager.sendMessage(anyString(), anyString(), anyString(),
 * anyString(), anyString(), anyString(), anyString()))
 * .thenReturn(failedFuture) .thenReturn(failedFuture)
 * .thenReturn(successfulFuture);
 * 
 * String topic = kafkaProperties.getTopics().get(0).getName();
 * 
 * // Act ResponseEntity<String> response = kafkaPublishService.publish(topic,
 * "key", "message");
 * 
 * // Assert assertThat(response.getStatusCodeValue()).isEqualTo(200);
 * verify(producerManager, times(3)).sendMessage(anyString(), anyString(),
 * anyString(), anyString(), anyString(), anyString(), anyString()); }
 * 
 * @Test void testPublish_NoTopicConfig_Throws() { String invalidTopic =
 * "non-existent-topic";
 * 
 * IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, ()
 * -> { kafkaPublishService.publish(invalidTopic, "key", "msg"); });
 * 
 * assertThat(ex.getMessage()).contains("No security config found for topic"); }
 * }
 */