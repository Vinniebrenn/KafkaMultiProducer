package com.example.streambridge.interceptor;

 	
import org.apache.kafka.clients.producer.RecordMetadata;
import com.example.streambridge.dto.KafkaPublishRequest;

public interface KafkaInterceptor {

    /**
     * Transform/enrich the request before publishing.
     * Can include encryption, audit tagging, localization, etc.
     */
    KafkaTransformedRecord prePublish(String topic, KafkaPublishRequest original);

    /**
     * Hook after successful publish.
     */
    void postPublish(String topic, KafkaTransformedRecord transformed, RecordMetadata metadata);

    /**
     * Hook when error occurs during send.
     */
    void onError(String topic, KafkaTransformedRecord transformed, Exception e);
}
