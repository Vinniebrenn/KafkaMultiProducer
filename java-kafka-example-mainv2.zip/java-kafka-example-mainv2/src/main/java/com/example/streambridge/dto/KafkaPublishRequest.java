package com.example.streambridge.dto;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KafkaPublishRequest {

    @NotBlank
    private String topic;

    @NotBlank
    private String key;

    @Schema(description = "Structured payload")
    private Map<String, Object> payload;

    private Integer partition;

    private Map<String, String> headers;
    
    /**
     * Serializes the payload as a JSON string.
     * @return serialized message
     */
    @JsonIgnore
    public String getMessage() {
        try {
            return new ObjectMapper().writeValueAsString(payload);
        } catch (Exception e) {
            // Optional: log it if needed
            return "{}";
        }
    }
}
