package com.example.streambridge.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.example.streambridge.interceptor.KafkaInterceptor;
import com.example.streambridge.interceptor.KafkaTopicInterceptor;

import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;

@Configuration
@RequiredArgsConstructor
public class InterceptorAutoRegistrar {

    private final ApplicationContext context;
    private final KafkaInterceptorRegistry registry;

    @PostConstruct
    public void autoRegisterTopicInterceptors() {
        context.getBeansOfType(KafkaInterceptor.class).forEach((name, bean) -> {
            KafkaTopicInterceptor annotation = bean.getClass().getAnnotation(KafkaTopicInterceptor.class);
            if (annotation != null) {
                registry.register(annotation.value(), bean);
            }
        });
    }
}
