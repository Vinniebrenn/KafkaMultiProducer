package com.example.streambridge.dto;

import java.time.Instant;

public class MessageMetadataFactory {

    public static MessageMetadata pending(String messageId) {
        return new MessageMetadata(
            messageId,
            MessageStatus.PENDING,
            null,
            Instant.now(),
            true
        );
    }

    public static MessageMetadata success(String messageId) {
        return new MessageMetadata(
            messageId,
            MessageStatus.SUCCESS,
            null,
            Instant.now(),
            false
        );
    }

    public static MessageMetadata failed(String messageId, String reason, boolean canRetry) {
        return new MessageMetadata(
            messageId,
            MessageStatus.FAILED,
            reason,
            Instant.now(),
            canRetry
        );
    }
}
