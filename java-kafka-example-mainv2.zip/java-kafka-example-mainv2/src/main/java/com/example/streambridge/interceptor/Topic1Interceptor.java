package com.example.streambridge.interceptor;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.stereotype.Component;

import com.example.streambridge.dto.KafkaPublishRequest;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
@KafkaTopicInterceptor("topic1")
public class Topic1Interceptor implements KafkaInterceptor {


	    @Override
	    public KafkaTransformedRecord prePublish(String topic, KafkaPublishRequest original) {
	        try {
	            return new KafkaTransformedRecord(
	                    original.getKey(),
	                    original.getMessage(),
	                    original.getHeaders()
	            );
	        } catch (Exception e) {
	            log.error("Failed to serialize payload for topic {}", topic, e);
	            // In worst case, fallback to toString()
	            return new KafkaTransformedRecord(
	                    original.getKey(),
	                    String.valueOf(original.getPayload()),
	                    original.getHeaders()
	            );
	        }
	    }

	    @Override
	    public void postPublish(String topic, KafkaTransformedRecord transformed, RecordMetadata metadata) {
	        // No-op
	    }

	    @Override
	    public void onError(String topic, KafkaTransformedRecord transformed, Exception e) {
	        // No-op or optional logging
	    }
	}
