package com.example.streambridge.dto;

public class MessageStatusResponse {

}
