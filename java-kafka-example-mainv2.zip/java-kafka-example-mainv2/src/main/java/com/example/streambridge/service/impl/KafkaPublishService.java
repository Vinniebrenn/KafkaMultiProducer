package com.example.streambridge.service.impl;

import java.util.HashMap;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;

import com.example.streambridge.config.KafkaProperties;
import com.example.streambridge.dto.KafkaPublishRequest;
import com.example.streambridge.dto.MessageMetadataFactory;
import com.example.streambridge.util.KafkaInterceptorRegistry;
import com.example.streambridge.util.KafkaProducerManager;
import com.example.streambridge.util.MessageStatusStore;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class KafkaPublishService {

    private final KafkaProducerManager producerManager;
    private final KafkaProperties kafkaProperties;
    private final KafkaInterceptorRegistry interceptorRegistry;
    private final MessageStatusStore messageStatusStore;

    @Retryable(
        retryFor = { Exception.class },  
        maxAttempts = 3,
        backoff = @Backoff(delay = 1000)
    )
    public void sendWithRetry(KafkaPublishRequest request) throws Exception {
        KafkaProperties.TopicSecurity topicSecurity = kafkaProperties.getTopics().stream()
            .filter(t -> t.getName().equals(request.getTopic()))
            .findFirst()
            .orElseThrow(() -> new IllegalArgumentException("No config for topic: " + request.getTopic()));

        CompletableFuture<RecordMetadata> future = producerManager.sendMessage(
            request,
            topicSecurity,
            kafkaProperties.getTruststore(),
            kafkaProperties.getBootstrapServers(),
            interceptorRegistry.get(request.getTopic())
        );

        // Wait for send to complete to trigger retry on failure
        future.get();
    }

    public ResponseEntity<String> publish(KafkaPublishRequest request) {
        // Ensure headers map exists
        if (request.getHeaders() == null) {
            request.setHeaders(new HashMap<>());
        }

        // Reuse messageId if already set (for retries), else generate new
        String messageId = request.getHeaders().getOrDefault("messageId", UUID.randomUUID().toString());
        request.getHeaders().put("messageId", messageId);
        

        // Initialize status if not present
        messageStatusStore.put(messageId, MessageMetadataFactory.pending(messageId));

        try {
            sendWithRetry(request);
            messageStatusStore.put(messageId, MessageMetadataFactory.success(messageId));
        } catch (Exception e) {
            log.error("Failed to publish message, messageId={}", messageId, e);
            messageStatusStore.put(messageId, MessageMetadataFactory.failed(messageId, e.getMessage(), true));
        }

        // Return immediately with message ID for client polling
        return ResponseEntity.accepted().body("Message accepted, id: " + messageId);
    }
}
