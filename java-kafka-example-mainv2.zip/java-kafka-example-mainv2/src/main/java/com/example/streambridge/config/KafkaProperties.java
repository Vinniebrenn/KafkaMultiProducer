package com.example.streambridge.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "kafka")
public class KafkaProperties {

    private String bootstrapServers;
    private Truststore truststore;
    private List<TopicSecurity> topics;

    @Data
    public static class Truststore {
        private String location;
        private String password;
    }

    @Data
    public static class TopicSecurity {
        private String name;
        private String jaasConfig;
    }
}
