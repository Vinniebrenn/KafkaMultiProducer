package com.example.streambridge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.streambridge.dto.KafkaPublishRequest;
import com.example.streambridge.service.impl.KafkaPublishService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1/kafka")
@Slf4j
public class KafkaController {

    private final KafkaPublishService publishService;

    public KafkaController(KafkaPublishService publishService) {
        this.publishService = publishService;
    }

    @Operation(summary = "Publish message to Kafka topic")
    @PostMapping("/publish")
    public ResponseEntity<String> publish(@Valid @RequestBody KafkaPublishRequest request) {
        log.info("Received publish request - topic: {}, key: {}", request.getTopic(), request.getKey());
        return publishService.publish(request);
    }
}
