package com.example.streambridge.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.IpAddressMatcher;

@Configuration
public class WebSecurityConfig {

    private final SecurityProperties securityProperties;

    @Autowired
    public WebSecurityConfig(SecurityProperties securityProperties) {
        this.securityProperties = securityProperties;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> {
                // Always allow Swagger
                auth.requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll();

                if (securityProperties.getAllowedIps() != null && !securityProperties.getAllowedIps().isEmpty()) {
                    // Allow requests from allowed IPs without authentication
                    auth.requestMatchers(request -> 
                        securityProperties.getAllowedIps().stream()
                            .anyMatch(ip -> new IpAddressMatcher(ip).matches(request))
                    ).permitAll();

                    // Deny all other requests
                    auth.anyRequest().denyAll();
                } else {
                    // No IP restriction — allow everything
                    auth.anyRequest().permitAll();
                }
            })
            // Disable HTTP Basic auth and form login — no login prompt
            .httpBasic(httpBasic -> httpBasic.disable())
            .formLogin(formLogin -> formLogin.disable());

        return http.build();
    }
}
