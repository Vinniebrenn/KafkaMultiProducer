package com.example.streambridge.util;

import com.example.streambridge.dto.MessageMetadata;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
public class MessageStatusStore {

    private final Cache<String, MessageMetadata> cache = Caffeine.newBuilder()
        .expireAfterWrite(Duration.ofDays(1))  // TTL can be tuned
        .maximumSize(10_000)
        .build();

    public void put(String messageId, MessageMetadata metadata) {
        cache.put(messageId, metadata);
    }

    public MessageMetadata get(String messageId) {
        return cache.getIfPresent(messageId);
    }

    public void putIfAbsent(String messageId, MessageMetadata metadata) {
        cache.asMap().putIfAbsent(messageId, metadata);
    }
}
