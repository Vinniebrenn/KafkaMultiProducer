package com.example.streambridge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StreamBridgeKafkaApp {

    public static void main(String[] args) {
        SpringApplication.run(StreamBridgeKafkaApp.class, args);
    }
}
