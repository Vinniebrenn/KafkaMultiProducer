package com.example.streambridge.dto;

public enum MessageStatus {
    PENDING,
    SUCCESS,
    FAILED
}
