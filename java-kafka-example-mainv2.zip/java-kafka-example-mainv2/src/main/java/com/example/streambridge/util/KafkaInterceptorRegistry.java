package com.example.streambridge.util;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.example.streambridge.interceptor.KafkaInterceptor;
import com.example.streambridge.interceptor.NoOpKafkaInterceptor;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaInterceptorRegistry {

    // Add interceptors here or inject them via Spring
    private final Map<String, KafkaInterceptor> interceptors = new ConcurrentHashMap<>();

    // Returns interceptor or NoOp
    public KafkaInterceptor get(String topic) {
        return interceptors.getOrDefault(topic, new NoOpKafkaInterceptor());
    }

    public void register(String topic, KafkaInterceptor interceptor) {
        interceptors.put(topic, interceptor);
        log.info("Registered interceptor for topic: {}", topic);
    }
}
