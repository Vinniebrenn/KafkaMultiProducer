package com.example.streambridge.dto;

import java.time.Instant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class MessageMetadata {
    private String messageId;
    private MessageStatus  status;     // e.g., PENDING, SUCCESS, FAILED
    private String reason;     // e.g., "Kafka timeout", "Invalid topic"
    private Instant timestamp; // when status was last updated
    private boolean canRetry;  // client hint
}
