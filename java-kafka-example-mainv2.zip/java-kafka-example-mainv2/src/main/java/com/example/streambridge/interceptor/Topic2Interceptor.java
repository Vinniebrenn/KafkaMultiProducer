package com.example.streambridge.interceptor;

import com.example.streambridge.dto.KafkaPublishRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Component
@KafkaTopicInterceptor("topic2")
public class Topic2Interceptor implements KafkaInterceptor {

    private static final String SECRET = "My16ByteSecretKey";

    @Override
    public KafkaTransformedRecord prePublish(String topic, KafkaPublishRequest original) {
        try {
            String encryptedKey = encryptAES(original.getKey(), SECRET);
            String encryptedValue = encryptAES(original.getMessage(), SECRET);
            log.info("[{}] Encrypted key & message for topic '{}'", getCorrelationId(), topic);

            Map<String, String> enrichedHeaders = new HashMap<>(original.getHeaders());
            enrichedHeaders.put("audit-user", "system@api");

            return new KafkaTransformedRecord(encryptedKey, encryptedValue, enrichedHeaders);
        } catch (Exception e) {
            log.error("[{}] Encryption failed for topic '{}'", getCorrelationId(), topic, e);
            return new KafkaTransformedRecord(original.getKey(), original.getMessage(), original.getHeaders());
        }
    }

    @Override
    public void postPublish(String topic, KafkaTransformedRecord transformed, RecordMetadata metadata) {
        log.info("[{}] Kafka published to topic='{}' offset={}", getCorrelationId(), topic, metadata.offset());
    }

    @Override
    public void onError(String topic, KafkaTransformedRecord transformed, Exception e) {
        log.error("[{}] Kafka publish error to topic='{}'", getCorrelationId(), topic, e);
    }

    private String encryptAES(String data, String key) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key.getBytes(), "AES"));
        return Base64.getEncoder().encodeToString(cipher.doFinal(data.getBytes()));
    }

    private String getCorrelationId() {
        return MDC.get("correlationId");
    }
}
