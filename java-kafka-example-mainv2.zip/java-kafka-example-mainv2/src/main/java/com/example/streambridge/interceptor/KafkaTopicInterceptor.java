package com.example.streambridge.interceptor;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface KafkaTopicInterceptor {
    String value(); // topic name
}