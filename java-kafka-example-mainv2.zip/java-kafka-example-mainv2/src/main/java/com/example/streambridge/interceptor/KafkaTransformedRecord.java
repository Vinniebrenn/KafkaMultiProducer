package com.example.streambridge.interceptor;


import java.util.Collections;
import java.util.Map;

public class KafkaTransformedRecord {
    private final String key;
    private final String value;
    private final Map<String, String> headers;

    public KafkaTransformedRecord(String key, String value, Map<String, String> headers) {
        this.key = key;
        this.value = value;
        this.headers = headers != null ? Collections.unmodifiableMap(headers) : Collections.emptyMap();
    }

    public String getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }
}
