package com.example.streambridge.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.streambridge.dto.MessageMetadata;
import com.example.streambridge.util.MessageStatusStore;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/kafka")
@RequiredArgsConstructor
public class MessageStatusController {

	private final MessageStatusStore messageStatusStore;

	@GetMapping("/message-status/{messageId}")
	public ResponseEntity<MessageMetadata> getStatus(@PathVariable String messageId) {
		MessageMetadata metadata = messageStatusStore.get(messageId);

		if (metadata == null) {
			return ResponseEntity.notFound().build();
		}

		return ResponseEntity.ok(metadata);
	}
}